/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;

/**
 *
 * @author User
 */
public class formVender {
     public void carregaComboBox(JComboBox JCB)  
    {  
            try  
            {  
                JCB.addItem("SEXO");
                Conexao c = new Conexao();
                Statement statement = c.con.createStatement();  
                ResultSet rs =statement.executeQuery("SELECT nome FROM estoque " );  
                while(rs.next())  
                { 
                   JCB.addItem(rs.getString("nome"));  
                    System.out.println(rs.getString("nome"));
                }  
                rs.close(); 
            }  
            catch(Exception e)  
            {  
                JOptionPane.showMessageDialog(null,   
                        "Ocorreu erro ao carregar a Combo Box", "Erro",  
                        JOptionPane.ERROR_MESSAGE);  
         }       
    }
}
