/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Class;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import main.Editar_Os;
import main.Listar_Os;
import main.OS;
import main.Vendas_Os;

public class formOS {

    public void insert(OS os) {
        String sql1 = "INSERT INTO OS(nome,telefone1,telefone2,email,placa,chassi,endereço,descricao) VALUES('" + os.getjTextField1().getText() + "','" + os.getjTextField5().getText() + "','" + os.getjTextField6().getText() + "','" + os.getjTextField7().getText() + "','" + os.getjTextField2().getText() + "','" + os.getjTextField3().getText() + "','" + os.getjTextField4().getText() + "','" + os.getjTextArea1().getText() + "')";

        try {
            Conexao c = new Conexao();
            Statement statement = c.con.createStatement();
            statement.execute(sql1);
            statement.close();
        } catch (SQLException ex) {
            Logger.getLogger(formOS.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public void tabela(Listar_Os lo) throws SQLException {
        Conexao c = new Conexao();
        PreparedStatement stmt = c.con.prepareStatement("select * from os ORDER BY id ASC");

//Crie um resultset para receber os dados do banco
        ResultSet rs = stmt.executeQuery();

//instancie um novo modelo de tabela
        DefaultTableModel modelo = (DefaultTableModel) lo.getjTable1().getModel();
        modelo.setNumRows(0);

        try {
            while (rs.next()) {
                //Aqui você adiciona os campos do banco de dados no jTable. 
                modelo.addRow(new Object[]{rs.getString("Id"), rs.getString("nome"), rs.getString("placa"), rs.getString("chassi"), rs.getString("endereço"), rs.getString("telefone1"), rs.getString("telefone2"), rs.getString("email")});
            }
            rs.first();
        } catch (SQLException ex) {
            Logger.getLogger(formEstoque.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void descricao(String id) throws SQLException {
        Conexao c = new Conexao();
        PreparedStatement stmt = c.con.prepareStatement("select descricao from os where id =" + id + "");
        ResultSet rs = stmt.executeQuery();
        rs.next();
        JOptionPane.showMessageDialog(null, "Descrição: " + rs.getString("descricao"));
    }

    public void pesquisar(Editar_Os eo) {
        try {
            Conexao c = new Conexao();
            PreparedStatement stmt = null;
            try {
                stmt = c.con.prepareStatement("select * from os where id = '" + eo.getjTextField2().getText() + "'");
            } catch (SQLException ex1) {
                Logger.getLogger(formEstoque.class.getName()).log(Level.SEVERE, null, ex1);
            }
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                eo.getjTextField8().setText(rs.getString("placa"));
                eo.getjTextField7().setText(rs.getString("Id"));
                eo.getjTextField1().setText(rs.getString("nome"));
                eo.getjTextField3().setText(rs.getString("chassi"));
                eo.getjTextField4().setText(rs.getString("endereço"));
                eo.getjTextField5().setText(rs.getString("telefone1"));
                eo.getjTextField6().setText(rs.getString("telefone2"));
                eo.getjTextField9().setText(rs.getString("email"));
                eo.getjTextArea1().setText(rs.getString("descricao"));
            } else {
                JOptionPane.showMessageDialog(null, "não existe esse id , tente outro");
            }
        } catch (SQLException ex1) {

            Logger.getLogger(formEstoque.class.getName()).log(Level.SEVERE, null, ex1);
        }

    }

    public void excluir(Editar_Os eo) throws SQLException {
        Conexao c = new Conexao();
        String sql1 = "delete from os where id = " + eo.getjTextField7().getText() + "";
        Statement statement = c.con.createStatement();
        statement.execute(sql1);
        statement.close();
    }

    public void editar(Editar_Os os) throws SQLException {
        Conexao c = new Conexao();
        String sql1 = "update os set nome='" + os.getjTextField1().getText() + "',telefone1='" + os.getjTextField5().getText() + "',telefone2='" + os.getjTextField6().getText() + "',email='" + os.getjTextField9().getText() + "',placa='" + os.getjTextField8().getText() + "',chassi='" + os.getjTextField3().getText() + "',endereço='" + os.getjTextField4().getText() + "',descricao='" + os.getjTextArea1().getText() + "' where id='" + os.getjTextField2().getText() + "'; ";
        Statement statement = c.con.createStatement();
        statement.execute(sql1);
        statement.close();
    }

    public void pesquisar_lista(Listar_Os lo) throws SQLException {
        Conexao c = new Conexao();
        PreparedStatement stmt = c.con.prepareStatement("select * from os where nome like '" + lo.getjTextField1().getText() + "%';");
        ResultSet rs = stmt.executeQuery();
        if (rs.next()) {
            rs.previous();
            DefaultTableModel modelo = (DefaultTableModel) lo.getjTable1().getModel();
            modelo.setNumRows(0);
            try {
                while (rs.next()) {
                    modelo.addRow(new Object[]{rs.getString("Id"), rs.getString("nome"), rs.getString("placa"), rs.getString("chassi"), rs.getString("endereço"), rs.getString("telefone1"), rs.getString("telefone2"), rs.getString("email")});
                }
                rs.first();
            } catch (SQLException ex) {
                Logger.getLogger(formEstoque.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else {
            JOptionPane.showMessageDialog(null, "Não existe esse nome");
        }
    }
    
    public void Vendas_Os(Vendas_Os lo) throws SQLException {
        
        Conexao c = new Conexao();
        PreparedStatement stmt1 = c.con.prepareStatement("select vendas.id from os,vendas where os.nome = '"+lo.getjTextField1().getText()+"' ;");
        ResultSet rs1 = stmt1.executeQuery();
        rs1.next();
        String id = rs1.getString("id");
         c = new Conexao();
        PreparedStatement stmt = c.con.prepareStatement("select estoque.nome,venda.quantidade,venda.total,os.nome,venda.data from os,venda,estoque Where venda.Id_os='"+id+"';");
        ResultSet rs = stmt.executeQuery();
        if (rs.next()) {
            rs.previous();
            DefaultTableModel modelo = (DefaultTableModel) lo.getjTable1().getModel();
            modelo.setNumRows(0);
            try {
                while (rs.next()) {
                    modelo.addRow(new Object[]{rs.getString("Id"), rs.getString("nome"), rs.getString("placa"), rs.getString("chassi"), rs.getString("endereço"), rs.getString("telefone1"), rs.getString("telefone2"), rs.getString("email")});
                }
                rs.first();
            } catch (SQLException ex) {
                Logger.getLogger(formEstoque.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else {
            JOptionPane.showMessageDialog(null, "Não existe esse nome");
        }
    }

}
