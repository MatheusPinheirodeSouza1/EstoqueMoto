/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author User
 */
public class formOS {
    Connection connection;
    public formOS(){
          try {
            connection = new ConnectionFactory().getConnection();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(ClienteDAO.class.getName()).log(Level.SEVERE, null, ex);

        } catch (IOException ex) {
            Logger.getLogger(ClienteDAO.class.getName()).log(Level.SEVERE, null, ex);

        }
    }
    public void insert(OS os) {

        String sql1 = "INSERT INTO cliente VALUES(" + os.jTex + ",'" + cliente.getNome() + "')";

        try {
            Statement statement = connection.createStatement();
            statement.execute(sql1);
            statement.close();
        } catch (SQLException ex) {

            throw new RuntimeException();
        }
    }
}
