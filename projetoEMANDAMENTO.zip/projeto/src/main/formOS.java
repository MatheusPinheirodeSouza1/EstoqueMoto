/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import static main.Conexão.con;

/**
 *
 * @author User
 */
 public class formOS{
     public void insert(OS os){
          String sql1 = "INSERT INTO OS(nome,placa,chassi,endereco,telefone1,telefone2,descricao) VALUES(" + os.getjTextField1()+ ",'" + os.getjTextField2()+",'" + os.getjTextField3()+",'" + os.getjTextField4()+",'" + os.getjTextField5()+",'" + os.getjTextField6()+",'" + os.getjTextField7()+"')";
         try {
             Statement statement = con.createStatement();
             statement.execute(sql1);
              statement.close();
         } catch (SQLException ex) {
             Logger.getLogger(formOS.class.getName()).log(Level.SEVERE, null, ex);
         }
           
     }
 }






