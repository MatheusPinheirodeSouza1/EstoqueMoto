/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Class;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.awt.Desktop;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import main.viewPDF;

/**
 *
 * @author User
 */
public class formPDF {
              public void formPDF(viewPDF pv){
                  Document documento = new Document();
                  // TA 
                    JOptionPane.showMessageDialog(null,pv.getjTextField1().getText());
                    String teste = "MATHEUS TESTE 1";
                  try {
                      PdfWriter.getInstance(documento, new FileOutputStream("Relatorio.pdf"));
                      documento.open();
                      documento.setPageSize(PageSize.A4);
                      documento.add(new Paragraph(pv.getjTextField1().getText()));
                      
                      
                  } catch (FileNotFoundException | DocumentException ex) {
                      Logger.getLogger(formPDF.class.getName()).log(Level.SEVERE, null, ex);
                  }finally{
                      documento.close();
                  }
              
                  try {
                      Desktop.getDesktop().open(new File("Relatorio.pdf"));
                  } catch (IOException ex) {
                      Logger.getLogger(formPDF.class.getName()).log(Level.SEVERE, null, ex);
                  }
              }
}   
