/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Class;

import java.sql.*;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import main.Adicionar_estoque;
import main.Excluir_estoque;
import main.Listar_estoque;

/**
 *
 * @author matheus
 */
public class formEstoque {

    public void insert(Adicionar_estoque ae) {
        Date data = new Date(System.currentTimeMillis());
        SimpleDateFormat formatarDate = new SimpleDateFormat("yyyy-MM-dd HH:MM:s");
        String sql1 = "insert into estoque(nome,qnt,data_entrada,preco) values('" + ae.getjTextField1().getText() + "'," + ae.getjTextField4().getText() + ",'" + formatarDate.format(data) + "','" + ae.getjTextField3().getText() + "');";
        try {
            Conexao c = new Conexao();
            Statement statement = c.con.createStatement();
            statement.execute(sql1);
            statement.close();
        } catch (SQLException ex) {
            Logger.getLogger(formEstoque.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public void tabela(Listar_estoque le) throws SQLException {
        Conexao c = new Conexao();
        PreparedStatement stmt = c.con.prepareStatement("select * from estoque ORDER BY id ASC");

//Crie um resultset para receber os dados do banco
        ResultSet rs = stmt.executeQuery();

//instancie um novo modelo de tabela
        DefaultTableModel modelo = (DefaultTableModel) le.getjTable1().getModel();
        modelo.setNumRows(0);

        try {
            while (rs.next()) {
                //Aqui você adiciona os campos do banco de dados no jTable. 
                modelo.addRow(new Object[]{rs.getString("Id"), rs.getString("nome"), rs.getInt("qnt"), rs.getString("data_entrada"), rs.getString("preco")});
            }
            rs.first();
        } catch (SQLException ex) {
            Logger.getLogger(formEstoque.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void pesquisar(Excluir_estoque ex) {
        try {
            Conexao c = new Conexao();
            PreparedStatement stmt = null;
            try {
                stmt = c.con.prepareStatement("select * from estoque where Id = " + ex.getjTextField2().getText() + "");
            } catch (SQLException ex1) {

                Logger.getLogger(formEstoque.class.getName()).log(Level.SEVERE, null, ex1);
            }
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                ex.getjTextField6().setText(rs.getString("Id"));
                ex.getjTextField1().setText(rs.getString("nome"));
                ex.getjTextField3().setText(rs.getString("preco"));
                ex.getjTextField4().setText(rs.getString("qnt"));
                ex.getjTextField5().setText(rs.getString("data_entrada"));
            }else{
                JOptionPane.showMessageDialog(null, "não existe esse id, tente outro");
            }
        } catch (SQLException ex1) {
            Logger.getLogger(formEstoque.class.getName()).log(Level.SEVERE, null, ex1);
        }

    }

    public void excluir(Excluir_estoque ex) throws SQLException {
        System.out.println(ex.getjTextField6().getText());
        Conexao c = new Conexao();
        String sql1 = "delete from estoque where Id = '" + ex.getjTextField6().getText() + "'";
        Statement statement = c.con.createStatement();
        statement.execute(sql1);
        statement.close();
    }
}
