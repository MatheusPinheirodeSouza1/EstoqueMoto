/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;


import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author User
 */
 public class formOS{
     public void insert(OS os){
          String sql1 = "INSERT INTO OS(nome,telefone1,telefone2,email,placa,chassi,id_venda,endereco,descricao) VALUES('" + os.getjTextField1().getText()+ "','" + os.getjTextField5().getText()+"','" + os.getjTextField6().getText()+"','" + os.getjTextField7().getText()+"','" + os.getjTextField2().getText()+"','" + os.getjTextField3().getText()+"','" + /*tabela venda*/os.getjTextField4().getText() +"','" + os.getjTextField8().getText()+"')";
         try {
             Conexao c = new Conexao();
             Statement statement = c.con.createStatement();
             statement.execute(sql1);
              statement.close();
         } catch (SQLException ex) {
             Logger.getLogger(formOS.class.getName()).log(Level.SEVERE, null, ex);
         }
           
     }
 }






